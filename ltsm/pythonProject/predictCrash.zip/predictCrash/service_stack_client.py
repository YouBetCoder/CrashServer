from servicestack import JsonServiceClient

client = JsonServiceClient('https://localhost:5001')
