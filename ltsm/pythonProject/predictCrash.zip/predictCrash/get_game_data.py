from time import sleep

from predictCrash.dtos import QueryActiveGameRoom, ActiveGameRoom
from predictCrash.service_stack_client import client


def get_data():
    response = client.get(QueryActiveGameRoom(), args={'OrderByDesc': 'Id', 'Take': 1000})
    items = response.results
    items.reverse()
    data = list(map(lambda x: float(x.game_result), items)) # Apply conversion to float here
    return items, data


def get_next_game(last_round_id):
    items, data = get_data()
    while True:
        last_game: ActiveGameRoom = items[-1]

        if last_game.round_id != last_round_id:
            return items, data, last_game, last_game.round_id
        items, data = get_data()
        sleep(2)
