import decimal
import time
from _decimal import Decimal
from typing import List

import numpy

from predictCrash.arima import predict_next_decimal_arima
from predictCrash.dtos import CreateActiveGameRoomPrediction, QueryActiveGameRoom
from predictCrash.fb_prophet import predict_next_result_prophet, predict_next_result_prophet2
from predictCrash.get_game_data import get_next_game

from predictCrash.service_stack_client import client

decimal_0 = decimal.Decimal(0)
from discord_webhook import DiscordWebhook


def send_webook(msg):
    try:
        webhook = DiscordWebhook(
            url="https://discord.com/api/webhooks/1282964217497915435/hP3pjssrp9wO7wzwxD-aTHVP7V2W0Dx0zeC8tdBaPBMTuwzBHhwVId2wuutGuQxFAcZy",
            content=msg)
        response = webhook.execute()
    except Exception as e:
        print(str(e))


def check_items(items: List[QueryActiveGameRoom]) -> bool:
    last_30 = items[-30:]
    current = last_30[0]
    for i in range(1, len(last_30)):
        next = last_30[i]
        # print(f"{current.round_id} -> {next.round_id}")
        if current.round_id + 1 != next.round_id:
            time.sleep(2)
            return False
        current = next
    return True


def wait_and_predict(prev_round_id):
    items, data, last_game, last_round_id = get_next_game(prev_round_id)
    if len(items) < 30:
        print("Not enough data to make predictions")
        return False
    if not check_items(items):
        print("Not enough sequential data to make predictions")
        return
    if prev_round_id == last_round_id:
        return
    room_id = last_game.room_id
    game_number = last_game.game_number

    print(f"Looking at game {game_number} round {last_round_id} room {room_id}")
    last_30 = data[-30:]
    last_302 = data[-30:]
    arima_result = predict_next_decimal_arima(last_30)
    #
    # next_result = predict_next_result3(last_30)
    # if isinstance(next_result, numpy.float32):
    #     decimal_result = Decimal(float(next_result))
    # else:
    #     decimal_result = Decimal(float(next_result[0][0]))
    #
    # decimal_result2 = weighted_average(last_30)
    # # if isinstance(next_result2, numpy.float32):
    # #     decimal_result2 = Decimal(float(next_result2))
    # # else:
    # #     decimal_result2 = Decimal(float(next_result2[0][0]))
    #
    # decimal_result3 = decimal.Decimal(0)
    # # next_result3 = predict_next_result3(data[-10:])
    # # if isinstance(next_result3, numpy.float32):
    # #     decimal_result3 = Decimal(float(next_result3))
    # # else:
    # #     decimal_result3 = Decimal(float(next_result3[0][0]))
    #
    std_dev = numpy.std(last_30)
    # # decimal_result3 = weighted_average(data[:-100])
    decimal_result_3 = predict_next_result_prophet2(last_302)
    decimal_result4 = predict_next_result_prophet(last_30)
    # if isinstance(next_result4, numpy.float32):
    #     decimal_result4 = Decimal(float(next_result4))
    # else:
    #     decimal_result4 = Decimal(float(next_result4[0][0]))

    output_of_predict = (f"Last game is {last_game.round_id} in room {room_id}, Next game ({last_game.round_id + 1}) "
                         f"result should be:\n "
                         f"Arima says {arima_result} \n"
                         f"Prediction 3 (weighted): {decimal_result_3} \n"
                         f"Prediction 4: {decimal_result4} \n"
                         f"Std Dev: {std_dev}\n")
    print(output_of_predict)
    send_webook(output_of_predict)
    # result: CreateActiveGameRoomPrediction = CreateActiveGameRoomPrediction(game_number=game_number, room_id=room_id,
    #                                                                         active_game_room_id=None,
    #                                                                         prediction=decimal_0,
    #                                                                         round_id=last_game.round_id + 1,
    #                                                                         prediction2=decimal_0,
    #                                                                         prediction3=decimal_0,
    #                                                                         prediction4=decimal_result4,
    #                                                                         prediction_arima=arima_result)
    # post_result = client.post(result)
    #print(post_result)
    return last_round_id
