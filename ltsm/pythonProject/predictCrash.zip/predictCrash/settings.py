n_past = 60
